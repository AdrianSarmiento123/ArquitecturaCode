import React, { useEffect, useState } from 'react';
import providerService from './providerService';

const DetalleTodosProveedores = () => {
  const [detalles, setDetalles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetalles = async () => {
      try {
        const res = await providerService.obtenerRecomendaciones();
        const proveedores = res.data;

        console.log('Proveedores base:', proveedores);

        const detallesPromises = proveedores.map((p) =>
          providerService
            .obtenerDetalleProveedor(p.id)
            .then((res) => res.data)
            .catch((err) => {
              console.error(`❌ Error al obtener detalle de proveedor ${p.id}`, err);
              return null;
            })
        );

        const detallesCompletos = await Promise.all(detallesPromises);
        setDetalles(detallesCompletos.filter(Boolean)); // elimina los null
      } catch (err) {
        console.error('Error al obtener lista de proveedores:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchDetalles();
  }, []);

  if (loading) return <p>Cargando detalles de proveedores...</p>;

  if (!detalles.length) return <p>❌ No se encontraron detalles para ningún proveedor.</p>;

  return (
    <div>
      <h2>📚 Detalle de Todos los Proveedores</h2>
      {detalles.map((detalle, index) => (
        <div key={index} style={{ border: '1px solid #ccc', marginBottom: '1rem', padding: '1rem' }}>
          <h3>🧾 {detalle.proveedor.nombre} ({detalle.proveedor.especialidad})</h3>

          <p>📧 {detalle.proveedor.correo}</p>
          <p>📱 {detalle.proveedor.telefono}</p>

          <h4>⭐ Calificaciones:</h4>
          {detalle.calificaciones.length ? (
            <ul>
              {detalle.calificaciones.map((c, i) => (
                <li key={i}>⭐ {c.puntuacion} - {c.comentario || 'Sin comentario'}</li>
              ))}
            </ul>
          ) : (
            <p>Sin calificaciones registradas.</p>
          )}

          <h4>🛠 Solicitudes:</h4>
          {detalle.solicitudes.length ? (
            <ul>
              {detalle.solicitudes.map((s, i) => (
                <li key={i}>{s.descripcion} - Estado: {s.estado}</li>
              ))}
            </ul>
          ) : (
            <p>Sin solicitudes asignadas.</p>
          )}

          <h4>📋 Historial de Mantenimiento:</h4>
          {detalle.historial.length ? (
            <ul>
              {detalle.historial.map((h, i) => (
                <li key={i}>{new Date(h.fecha).toLocaleString()} - {h.detalle}</li>
              ))}
            </ul>
          ) : (
            <p>Sin historial registrado.</p>
          )}
        </div>
      ))}
    </div>
  );
};

export default DetalleTodosProveedores;
